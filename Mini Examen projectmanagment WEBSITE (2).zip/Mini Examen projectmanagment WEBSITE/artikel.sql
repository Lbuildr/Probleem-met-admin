CREATE TABLE `producten` (
  `artikelcode` int(11) NOT NULL,
  `artikel` varchar(100) NOT NULL,
  `prijs` decimal(6,2) NOT NULL,
  `voorraad` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `producten`
  ADD PRIMARY KEY (`artikelcode`);

  -- AUTO_INCREMENT voor een tabel `artikel`--
ALTER TABLE `producten`
  MODIFY `artikelcode` int(11) NOT NULL AUTO_INCREMENT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
