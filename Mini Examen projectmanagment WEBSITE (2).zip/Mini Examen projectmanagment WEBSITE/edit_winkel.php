<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT-WINKEL</title>
</head>

<body>

    <?php

    // importeer database
    include_once 'Database.php';

    // maak een db instance
    $db =  new database();

//hier zorgen we ervoor dat de website blijft weten om welk personeels lid het gaat
    if (isset($_GET['winkel_id'])){
    $sql = "SELECT * FROM winkel WHERE winkelcode=:code";
    $result = $db->select($sql, ['code' => $_GET['winkel_id']]);
    if (count($result) > 0) {
        $winkelnaam = $result[0]['winkelnaam'];
        $winkeladres = $result[0]['winkeladres'];
        $winkelpostcode = $result[0]['winkelpostcode'];
        $vestigingsplaats = $result[0]['vestigingsplaats'];
        $telefoonnummer = $result[0]['telefoonnummer'];
    }
}


//eerst checken we of de wijzig button geklikt is & dan checken we of de request method(request naar de server een post is)
if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE winkel SET winkelnaam=:winkelnaam, winkeladres=:winkeladres, winkelpostcode=:winkelpostcode, vestigingsplaats=:vestigingsplaats, telefoonnummer=:telefoonnummer WHERE winkelcode = :code;";
        // $sql = "UPDATE personeel SET"; //naam=:naam, achternaam=:achternaam, email=:email WHERE personeelscode = :code;";

        // foreach($_POST as $kolom){
        //     if($kolom == 'naam'){
        //         $sql .= ' naam=:naam';
        //     }

        //     if($kolom == 'achternaam'){
        //         $sql 
        //     }
        // }


        //associative array 
        $placeholders = [
            'code' => $_POST['winkelcode'],
            'winkelnaam' => $_POST ['winkelnaam'],
            'winkeladres' => $_POST['winkeladres'],
            'winkelpostcode' => $_POST['winkelpostcode'],
            'vestigingsplaats' => $_POST['vestigingsplaats'],
            'telefoonnummer'=> $_POST['telefoonnummer']
        ];

        // roep functie aan uit je database class
        $db->update($sql, $placeholders,"beheer-winkel.php" );
    }
    ?>

<!--NOOIT GEBRUIKER VRAGEN OM HANDMATIG ID IN DATABASE TE WIJZIGEN-->
    <form action="edit_winkel.php" method="post">
        <input type="hidden" name="winkelcode" value="<?php echo isset($_GET['winkel_id']) ? $_GET['winkel_id'] : ''; ?>">
        <input type="text" name="winkelnaam" value="<?php echo isset($winkelnaam) ? $winkelnaam : 'winkelnaam' ?>">
        <input type="text" name="winkeladres" value="<?php echo isset($winkeladres) ? $winkeladres : 'winkeladres' ?>">
        <input type="text" name="winkelpostcode" value="<?php echo isset($winkelpostcode) ? $winkelpostcode : 'winkelpostcode' ?>">
        <input type="text" name="vestigingsplaats" value="<?php echo isset($vestigingsplaats) ? $vestigingsplaats : 'vestigingsplaats' ?>">
        <input type="text" name="telefoonnummer" value="<?php echo isset($telefoonnummer) ? $telefoonnummer : 'telefoonnummer' ?>">
        <input type="submit" name="submit" value="Wijzig">
    </form>

</body>

</html>