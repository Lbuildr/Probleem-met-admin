<?php
include 'Database.php';
$db = new database();
$bestellen = $db->select("SELECT * FROM bestellen", []);

$columns = array_keys($bestellen[0]);
$row_data = array_values($bestellen);

?>

<table>
    <tr>
        <?php

        foreach ($columns as $column) {
            echo "<th><strong> $column </strong></th>";
        }
        ?>
    </tr>
    <?php
    foreach ($row_data as $row) { ?>
        <tr>
        <?php
        foreach ($row as $data) {
            echo "<td> $data  </td>";
        }
    }
        ?>

</table>