<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-back_end-employee-page.css">
    <title>PERSONEEL-PAGINA</title>
</head>
<body>
    <?php include "back_end_menu-employee.php" ?>
    
<div class="welkom">
    <p class="welkom-text">Welkom terug Lucas</p>
    <p class="welkom-datum">uw laatste bezoek was</p>
    <p class="welkom-notificaties">notificaties = 10</p>

</div>


</body>
</html>