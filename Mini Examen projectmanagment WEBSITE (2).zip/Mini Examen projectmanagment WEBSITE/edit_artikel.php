<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT-ARTIKEL</title>
</head>

<body>

    <?php

    // importeer
    include_once 'Database.php';

    // maak een db instance
    $db =  new database();
    $sql = "SELECT * FROM producten WHERE artikelcode=:code";
    $result = $db->select($sql, ['code' => $_GET['artikel_id']]);
    if (count($result) > 0) {
        $artikel = $result[0]['artikel'];
        $prijs = $result[0]['prijs'];
        $voorraad = $result[0]['voorraad'];
    }



//eerst checken we of de wijzig button geklikt is & dan checken we of de request method(request naar de server een post is)
if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST')  {

        $sql = "UPDATE producten SET artikel=:artikel, prijs=:prijs, voorraad=:voorraad WHERE artikelcode = :code;";

        //associative array 
        $placeholders = [
            'code' => $_POST['artikelcode'],
            'artikel' => $_POST['artikel'],
            'prijs' => $_POST['prijs'],
            'voorraad' => $_POST['voorraad']
        ];



        // roep functie aan uit je database class
        $db->update($sql, $placeholders,"beheer-artikel.php" );
    }
    ?>
    <form action="edit_artikel.php" method="post">
        <input type="hidden" name="artikelcode" value="<?php echo isset($_GET['artikel_id']) ? $_GET['artikel_id'] : ''; ?>">
        <input type="text" name="artikel" value="<?php echo isset($artikel) ? $artikel : 'artikel' ?>">
        <input type="text" name="prijs" value="<?php echo isset($prijs) ? $prijs : 'prijs' ?>">
        <input type="text" name="voorraad" value="<?php echo isset($voorraad) ? $voorraad : 'voorraad' ?>">
        <input type="submit" name="submit" value="Wijzig">
    </form>

</body>

</html>