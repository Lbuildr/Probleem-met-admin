  <link rel="stylesheet" href="style-menu-home.css">

  <div class="navigation">
    <div class="logo">
      <a class="no-underline" href="#">
      <i class="fas fa-fish"></i>  De Hengelsport
      </a>
    </div>
    
      </a>
      <a href="loginpage-new.php" class="navigation-link">
      <i class="fas fa-sign-in-alt"></i>  
    </a>

      
    </div>

    <script>
      // double click on the heart icon
  $(".fa-heart").dblclick(function () {
    $(".notification-bubble").show(400);
  });

  $(document).on("scroll", function () {
    if ($(document).scrollTop() > 50) {
      $(".navigation").addClass("shrink");
    } else {
      $(".navigation").removeClass("shrink");
    }
  });
  </script>
  </div>