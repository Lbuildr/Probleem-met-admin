<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tussen-pagina</title>
</head>
<body>
<?php
session_start();
if(isset($_SESSION['loggedin'])){
include_once "Database.php";

$userType = $row['usertype'];
switch ($userType) {
    case '1':
        $redirect = 'Back_end_admin-page.php';
    break;
    // case '2':
    //     $redirect = 'moderator.php';
    // break;
    case '3':
        $redirect = 'back_end_employee-page.php';
    break;
require ($redirect);}
}

?>


</body>
</html>