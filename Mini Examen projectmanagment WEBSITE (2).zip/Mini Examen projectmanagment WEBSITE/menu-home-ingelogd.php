  <link rel="stylesheet" href="style-menu-home.css">

  <div class="navigation">
    <div class="logo">
      <a class="no-underline" href="#">
      <i class="fas fa-fish"></i>  De Hengelsport
      </a>
    </div>
    
    <div class="navigation-icons">
      <a href="loginpage.php" target ="_blank" class="navigation-link">
        <i class="far fa-compass"></i>
      </a>
      <a href="back_end_tussenpagina.php" class="navigation-link">
      <i class="fas fa-tasks"></i>
    </a>
      <a href="loguit.php" id="signout" class="navigation-link">
        <i class="fas fa-sign-out-alt"></i>
      </a>

  
      
    </div>

    <script>
      // double click on the heart icon
  $(".fa-heart").dblclick(function () {
    $(".notification-bubble").show(400);
  });

  $(document).on("scroll", function () {
    if ($(document).scrollTop() > 50) {
      $(".navigation").addClass("shrink");
    } else {
      $(".navigation").removeClass("shrink");
    }
  });
  </script>
  </div>