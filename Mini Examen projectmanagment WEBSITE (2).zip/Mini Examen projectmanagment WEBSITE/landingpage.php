<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-landingpage.css">
    <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>

    <title>CatchMoreFish</title>

</head>
<?php
session_start();
if(isset($_SESSION['loggedin'])){
    include "menu-home-ingelogd.php";
 } else{ 
     include "menu-home-geen-acc.php";
} ?>

<body>
  
    <!---------------------------------------Home Pagina Content------------------------------------->
    <div id="Hero">
        <video autoplay muted loop id="Video">
            <source position="cover" src="4k-fish.mp4" type="video/mp4">
        </video>
</div>

<!------------------Top-SECTION-END------------->
<!-----------------------------------------------start-CENTER---------------------------------------------->
<div class="ecommerce-cards">
<div class="card-container">
    <div class="card">
         <img src="hengel1.jpg" class="card-img">
            <div class="d-flex justify-content-between align-items-center mt-3 px-2">
                <h4>Hengel Start </h4> <span class="heart"><i class="fa fa-heart"></i></span>
            </div>
            <div class="mt-2 px-2"> <small> Hengel start is ontworpen voor de menen die eens in de zoveel tijd willen vissen en gewoon altijd 1 achter hebben staan.</small> </div>
            <div class="px-2">
                <h3>64.95</h3>
            </div>
            <div class="px-2 mt-3"> <button class="btn btn-primary px-3">Koop Nu!</button> <button class="btn btn-outline-primary px-3">Zet in winkelwagen</button> </div>
        </div>
    </div>

<div class="card-container">
    <div class="card">
         <img src="hengel1.jpg" class="card-img">
            <div class="d-flex justify-content-between align-items-center mt-3 px-2">
                <h4>Hengel </h4> <span class="heart"><i class="fa fa-heart"></i></span>
            </div>
            <div class="mt-2 px-2"> <small>Hengel is ontworpen om paar x per week te gebruiken. Deze is echt voor de "vrienden groep"</small> </div>
            <div class="px-2">
                <h3>89.95</h3>
            </div>
            <div class="px-2 mt-3"> <button class="btn btn-primary px-3">Koop Nu!</button> <button class="btn btn-outline-primary px-3">Zet in winkelwagen</button> </div>
        </div>
    </div>

    <div class="card-container">
    <div class="card">
         <img src="hengel1.jpg" class="card-img">
            <div class="d-flex justify-content-between align-items-center mt-3 px-2">
                <h4>Hengel Pro </h4> <span class="heart"><i class="fa fa-heart"></i></span>
            </div>
            <div class="mt-2 px-2"> <small>Hengel pro is voor de pro's. Ontworpen om elke dag te gebruiken en op te bergen.</small> </div>
            <div class="px-2">
                <h3>120</h3>
            </div>
            <div class="px-2 mt-3"> <button class="btn btn-primary px-3">Koop Nu!</button> <button class="btn btn-outline-primary px-3">Zet in winkelwagen</button> </div>
        </div>
    </div>

    <div class="card-container">
    <div class="card">
         <img src="hengel1.jpg" class="card-img">
            <div class="d-flex justify-content-between align-items-center mt-3 px-2">
                <h4>Hengel packet </h4> <span class="heart"><i class="fa fa-heart"></i></span>
            </div>
            <div class="mt-2 px-2"> <small>Hengel packet is voor de pro's. Dit packet bevat: Hengel pro + een hengel.</small> </div>
            <div class="px-2">
                <h3>177.99</h3>
            </div>
            <div class="px-2 mt-3"> <button class="btn btn-primary px-3">Koop Nu!</button> <button class="btn btn-outline-primary px-3">Zet in winkelwagen</button> </div>
        </div>
    </div>
</div>

</body>
<?php include "footer-main.php" ?>
</html>